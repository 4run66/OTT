//
//  Entity+CoreDataClass.swift
//  OTTProject
//
//  Created by Jo on 20/02/23.
//
//

import Foundation
import CoreData

@objc(Entity)
public class Entity: NSManagedObject {

}
