//
//  interestCVC.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class interestCVC: UICollectionViewCell {
    
    @IBOutlet var lblInterst: UILabel!
}
