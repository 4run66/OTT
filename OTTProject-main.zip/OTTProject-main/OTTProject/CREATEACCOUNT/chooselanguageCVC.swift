//
//  chooselanguageCVC.swift
//  OTTProject
//
//  Created by Jo on 27/01/23.
//

import UIKit

class chooselanguageCVC: UICollectionViewCell {
    
    @IBOutlet var lblLanguage: UILabel!
    @IBOutlet var imgmovie: UIImageView!
}
