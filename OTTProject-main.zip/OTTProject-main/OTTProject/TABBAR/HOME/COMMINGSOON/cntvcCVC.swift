//
//  cntvcCVC.swift
//  OTTProject
//
//  Created by Jo on 13/02/23.
//

import UIKit

class cntvcCVC: UICollectionViewCell {
    
    @IBOutlet var imgCast: UIImageView!
}
