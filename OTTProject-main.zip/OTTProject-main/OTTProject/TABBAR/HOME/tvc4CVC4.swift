//
//  tvc4CVC4.swift
//  OTTProject
//
//  Created by Jo on 16/02/23.
//

import UIKit

class tvc4CVC4: UICollectionViewCell {
    
    @IBOutlet var imgMVTrending: UIImageView!
}
