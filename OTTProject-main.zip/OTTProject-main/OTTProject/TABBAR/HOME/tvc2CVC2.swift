//
//  tvc2CVC1.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class tvc2CVC2: UICollectionViewCell {
    
    @IBOutlet var imgMovies: UIImageView!
    
}
