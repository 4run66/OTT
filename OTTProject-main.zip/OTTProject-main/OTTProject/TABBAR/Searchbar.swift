//
//  Searchbar.swift
//  OTTProject
//
//  Created by Jo on 28/02/23.
//

import UIKit

class Searchbar: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    // MARK: - Navigation

    
    @IBAction func btndidmiss(_ sender: UIButton) {
        
        dismiss(animated: true)
    }
    
}
