//
//  popularTVC.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class popularTVC: UITableViewCell {

    @IBOutlet var imgShow: UIImageView!
    @IBOutlet var lblTVName: UILabel!
    @IBOutlet var lblShowname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
