//
//  jonersCVC.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class jonersCVC: UICollectionViewCell {
    
    @IBOutlet var imgJoner: UIImageView!
    @IBOutlet var lblJoner: UILabel!
}
