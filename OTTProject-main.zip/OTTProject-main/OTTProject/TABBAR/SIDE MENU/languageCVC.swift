//
//  languageCVC.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class languageCVC: UICollectionViewCell {
    
    
    @IBOutlet var lblLanguage: UILabel!
    @IBOutlet var img: UIImageView!
    
}
