//
//  kidsCVC.swift
//  OTTProject
//
//  Created by Jo on 28/01/23.
//

import UIKit

class kidsCVC: UICollectionViewCell {
    
    @IBOutlet var imgMovies: UIImageView!
}
